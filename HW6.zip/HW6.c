//40223039-amir hossein salajegheh
#include<stdio.h>
#include <math.h>
float solver (float a,float b,float c);
float delta;
int number;
float answer1,answer2;
float *p1=&answer1,*p2=&answer2;
int main ()
{
    float a,b,c;
    printf("enter three numbers these are coefficients of quadratic equation\n");
    scanf("%f%f%f",&a,&b,&c);
    if(a==0  &&  b==0)
    {
        printf("your numbers are wrong ");
    }
    else
    {
    delta=(b*b)-(4*a*c);
    if(delta<0)
    {
        printf("this equation has no real roots");
    }
    else
      {
        solver(a,b,c);
        printf("this equation has %d roots and the answers are %f,%f",number,*p1,*p2);
      }
    }
}
float solver (float a,float b,float c)
{
    float y;
    if(a!=0)
    {
    if (delta>0)
    {
        number=2;
        y=sqrt(delta);
        answer1= (((-b)+y)/(2*a));
        answer2= (((-b)-y)/(2*a));
    }
     else if (delta==0)
    {
        number=1;
        answer1=(-b)/(2*a);
        *p2=*p1;
    }
    }
    else
    {
        number=1;
        answer1=(-b)/c;
        *p2=*p1;
    }
}